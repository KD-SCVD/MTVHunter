# 打开节点最终输出
import json

with open('features/tx.origin/tx.origin_train_feature.txt','r') as f:
    content = f.read().split('\n')
f.close()
datas =[]
for _ in  content:
    feature_list = _.split(',')
    single_node_feature_list =[float(x) for x in feature_list]
    datas.append(single_node_feature_list)
with open('tx.origin_MLP_train.json','w') as f:
    f.write(json.dumps(datas))
f.close()
