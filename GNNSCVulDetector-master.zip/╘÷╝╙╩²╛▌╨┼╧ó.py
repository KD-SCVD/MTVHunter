import json



if __name__ == '__main__':
    #创建合约名列表
    with open('tools/delegatecall/delegatecall_train.json','r') as f:
        data = json.load(f)
    f.close()
    all_contract_names = []# 合约名列表
    #提取数据标签
    all_contract_labels = []
    for _ in data:
        contract_name = _['contract_name']
        contract_target = _['targets']
        all_contract_names.append(contract_name)
        all_contract_labels.append(contract_target)

    # 打开节点最终输出
    with open('features/delegatecall/delegatecall_train_feature.txt','r') as f:
        content = f.read().split('\n')
    f.close()
    datas =[]
    for _ in  content:
        feature_list = _.split(',')
        single_node_feature_list =[float(x) for x in feature_list]
        datas.append(single_node_feature_list)

    source_features = []
    for i in range(len(all_contract_names)):
        dic = {}
        dic['contract_name'] = all_contract_names[i]
        dic['target'] = all_contract_labels[i]
        dic['source_features'] = datas[i]
        source_features.append(dic)
    with open('tx.origin_feature_train.json','w') as f:
        f.write('[')
        for i in range(len(source_features)):
            if i == len(source_features) - 1:
                data_final = json.dumps(source_features[i])
                f.write(data_final)
                f.write(']')
            else:
                data_final = json.dumps(source_features[i])
                f.write(data_final)
                f.write(',')
                f.write('\n')