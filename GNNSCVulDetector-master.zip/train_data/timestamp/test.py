import json
with open('train.json','r') as f:
    content = json.load(f)
    f.close()
f = open('train_1.json','a')
f.write('[')
for data in content:
    contract_name = data['contract_name']
    targets = data['targets']
    graph = data['graph_data']
    node_features = data['node_features']
    for i in range(len(node_features)):
        node_features[i] += [0]*(250-len(node_features[i]))
    s = {
        "contract_name": contract_name,
        "targets": targets,
        "graph_data": graph,
        "node_features":node_features
    }
    s= json.dumps(s)
    f.write(s)
    f.write(',')
    f.write('\n')
f.write(']')
f.close()