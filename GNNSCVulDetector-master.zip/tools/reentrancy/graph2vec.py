import os
import json
import numpy as np
from vec2onehot import vec2onehot
# vulnerability = ['1.sol', '10.sol', '100.sol', '1000.sol', '1001.sol', '101.sol', '1010.sol', '1011.sol', '11.sol',
#                  '110.sol', '1100.sol', '11000.sol', '11001.sol', '1101.sol', '11010.sol', '11011.sol', '111.sol',
#                  '1110.sol', '1111.sol', '12000.sol', '12002.sol', '12020.sol', '12022.sol', '13000.sol', '13003.sol',
#                  '13030.sol', '13033.sol', '14000.sol', '14004.sol', '14040.sol', '14044.sol', '15000.sol', '15005.sol',
#                  '15050.sol', '15055.sol', '2.sol', '20.sol', '200.sol', '2000.sol', '2002.sol', '202.sol', '2020.sol',
#                  '2022.sol', '21100.sol', '21101.sol', '21110.sol', '21111.sol', '22.sol', '220.sol', '2200.sol',
#                  '2202.sol', '222.sol', '2220.sol', '22200.sol', '22202.sol', '2222.sol', '22220.sol', '22222.sol',
#                  '23300.sol', '23303.sol', '23330.sol', '23333.sol', '24400.sol', '24404.sol', '24440.sol', '24444.sol',
#                  '25500.sol', '25505.sol', '25550.sol', '25555.sol', '3.sol', '30.sol', '300.sol', '3000.sol', '3003.sol',
#                  '303.sol', '3030.sol', '3033.sol', '33.sol', '330.sol', '3300.sol', '3303.sol', '333.sol', '3330.sol',
#                  '3333.sol', '36000.sol', '36006.sol', '36060.sol', '36066.sol', '4.sol', '40.sol', '400.sol', '4000.sol',
#                  '4004.sol', '404.sol', '4040.sol', '4044.sol', '44.sol', '440.sol', '4400.sol', '4404.sol', '444.sol',
#                  '4440.sol', '4444.sol', '46600.sol', '46606.sol', '46660.sol', '46666.sol', '5.sol', '50.sol', '500.sol',
#                  '5000.sol', '5005.sol', '505.sol', '5050.sol', '5055.sol', '55.sol', '550.sol', '5500.sol', '5505.sol',
#                  '555.sol', '5550.sol', '5555.sol', '57000.sol', '57007.sol', '57070.sol', '57077.sol', '6.sol', '60.sol',
#                  '600.sol', '6000.sol', '6006.sol', '606.sol', '6060.sol', '6066.sol', '66.sol', '660.sol', '6600.sol',
#                  '6606.sol', '666.sol', '6660.sol', '6666.sol', '67700.sol', '67707.sol', '67770.sol', '67777.sol', '7.sol',
#                  '70.sol', '700.sol', '7000.sol', '7007.sol', '707.sol', '7070.sol', '7077.sol', '77.sol', '770.sol',
#                  '7700.sol', '7707.sol', '777.sol', '7770.sol', '7777.sol',
#                  'aBank.sol', 'adumbDAO.sol', 'aEtherStore.sol','aPrivateBank.sol', 'aReentrancy01.sol', 'aSendBalance.sol','asimple_dao.sol',
#                  'bBank.sol','bdumbDAO.sol', 'bEtherStore.sol','bPrivateBank.sol', 'bReentrancy01.sol','bSendBalance.sol', 'bsimple_dao.sol',]
vulnerability = ['10041.sol', '10081.sol', '10840.sol', '11031.sol', '11044.sol', '11105.sol', '11137.sol','11276.sol', '11310.sol', '11651.sol', '12229.sol', '12326.sol', '12452.sol', '12705.sol',
                 '12727.sol', '12913.sol', '13171.sol', '13233.sol', '13236.sol', '13523.sol', '13709.sol', '13711.sol', '14025.sol', '1427.sol', '14350.sol', '14537.sol', '14562.sol', '14590.sol',
                 '14660.sol', '14817.sol', '14906.sol', '14983.sol', '15119.sol', '15131.sol', '15228.sol', '15266.sol', '15368.sol', '15585.sol', '15623.sol', '15816.sol', '1596.sol', '1611.sol',
                 '16126.sol', '16601.sol', '16801.sol', '16976.sol', '17034.sol', '17059.sol', '17062.sol', '1715.sol', '17224.sol', '17234.sol', '17255.sol', '17293.sol', '17311.sol', '17638.sol',
                 '18459.sol', '18639.sol', '18806.sol', '18900.sol', '19114.sol', '19120.sol', '19146.sol', '19769.sol', '19878.sol', '20089.sol', '20093.sol', '20161.sol', '20203.sol', '20221.sol',
                 '20239.sol', '20442.sol', '20549.sol', '20714.sol', '20817.sol', '20905.sol', '21307.sol',  '2132.sol', '21443.sol', '2157.sol', '21579.sol', '21746.sol', '22180.sol', '22413.sol',
                 '22608.sol', '22610.sol', '22713.sol', '23026.sol', '23286.sol', '23334.sol', '23392.sol',  '23481.sol', '23493.sol', '23561.sol', '23659.sol', '23779.sol', '23995.sol', '24001.sol',
                 '24258.sol', '2437.sol', '24414.sol', '24605.sol', '24863.sol', '24881.sol', '25009.sol', '25312.sol', '25553.sol', '25599.sol', '25806.sol', '26011.sol', '26064.sol', '26387.sol',
                 '26389.sol', '26515.sol', '26735.sol', '26844.sol', '26906.sol', '26930.sol', '27154.sol',  '27253.sol', '2730.sol', '27492.sol', '27923.sol', '27967.sol', '28035.sol', '28048.sol',
                 '28572.sol', '28616.sol', '28756.sol', '28767.sol', '28773.sol', '28799.sol', '28929.sol',  '29294.sol', '29448.sol', '29651.sol', '29667.sol', '29756.sol', '30023.sol', '30039.sol',
                 '30328.sol', '30364.sol', '30576.sol', '30702.sol', '30787.sol', '30952.sol', '31041.sol',  '31248.sol', '31256.sol', '31482.sol', '31540.sol', '31563.sol', '31608.sol', '31765.sol',
                 '31870.sol', '32014.sol', '32101.sol', '32343.sol', '32505.sol', '32569.sol', '32800.sol', '32853.sol', '33033.sol', '33109.sol', '33168.sol', '33170.sol', '33491.sol', '33852.sol',
                 '34044.sol', '3425.sol', '34436.sol', '34536.sol', '34587.sol', '34610.sol', '34626.sol', '34906.sol', '3509.sol', '35194.sol', '35597.sol', '35830.sol', '36044.sol', '36404.sol',
                 '36542.sol', '36559.sol', '36645.sol', '36662.sol', '36685.sol', '37329.sol', '37338.sol',
                 '37350.sol', '37547.sol', '37647.sol', '37835.sol', '37865.sol', '38358.sol', '38826.sol', '38856.sol', '39099.sol', '39114.sol', '39222.sol', '39579.sol', '39630.sol', '39674.sol',
                 '3968.sol', '39890.sol', '40176.sol', '40629.sol', '40632.sol', '40801.sol', '40896.sol', '40950.sol', '40992.sol', '41077.sol', '4110.sol', '41104.sol', '4117.sol',
                 '41211.sol', '41323.sol', '41375.sol', '41435.sol', '41447.sol', '41564.sol', '41735.sol', '41958.sol', '42041.sol', '42127.sol', '4216.sol', '42518.sol', '42769.sol',
                 '43195.sol', '43223.sol', '43243.sol', '43404.sol', '43812.sol', '43859.sol', '4424.sol', '44357.sol', '44383.sol', '44440.sol', '44485.sol', '45103.sol', '45185.sol',
                 '45227.sol', '45399.sol', '45550.sol', '45603.sol', '45640.sol', '45751.sol', '45762.sol', '45794.sol', '45819.sol', '45827.sol', '46098.sol', '46177.sol', '46384.sol',
                 '46388.sol', '46711.sol', '46912.sol', '47003.sol', '47175.sol', '47240.sol', '47859.sol', '47969.sol', '48100.sol', '48377.sol', '48543.sol', '49014.sol', '49050.sol',
                 '49073.sol', '49671.sol', '49798.sol', '50066.sol', '5026.sol', '50344.sol', '50769.sol', '50874.sol', '50935.sol', '50998.sol', '51012.sol', '51192.sol', '51703.sol', '51906.sol', '5195.sol', '52065.sol', '52174.sol',
                 '52360.sol', '52654.sol', '52693.sol', '52964.sol', '53112.sol', '53211.sol', '53543.sol', '54421.sol', '5465.sol', '54701.sol', '55288.sol', '55433.sol', '55580.sol',
                 '55899.sol', '55904.sol', '55990.sol', '56287.sol', '56391.sol', '56595.sol', '56653.sol', '56774.sol', '56894.sol', '56942.sol', '57455.sol', '57496.sol', '57529.sol',
                 '57739.sol', '57742.sol', '57871.sol', '58116.sol', '58154.sol', '58163.sol', '58384.sol', '58618.sol', '58722.sol', '59167.sol', '59287.sol', '59361.sol', '59882.sol',
                 '59896.sol', '6000.sol', '60162.sol', '60202.sol', '60206.sol', '60394.sol', '60400.sol', '60979.sol', '61657.sol', '61813.sol', '61881.sol', '61934.sol', '61948.sol',
                 '62516.sol', '62993.sol', '63084.sol', '63364.sol', '63689.sol', '64073.sol', '64264.sol', '64343.sol', '64426.sol', '64810.sol', '64892.sol', '64926.sol', '65073.sol',
                 '65328.sol', '65442.sol', '65767.sol', '66048.sol', '66206.sol', '66248.sol', '66310.sol', '66368.sol', '66391.sol', '66903.sol', '66904.sol', '67057.sol', '67649.sol',
                 '67803.sol', '6795.sol', '67999.sol', '68733.sol', '6890.sol', '69039.sol', '69065.sol', '69424.sol', '6947.sol', '6964.sol', '69713.sol', '7018.sol', '70326.sol',
                 '70425.sol', '70460.sol', '70466.sol', '70663.sol', '70816.sol', '70978.sol', '71047.sol', '7120.sol', '71324.sol', '71478.sol', '71717.sol', '71750.sol', '71889.sol',
                 '71940.sol', '72058.sol', '72291.sol', '72326.sol', '72658.sol', '72680.sol', '72719.sol', '72738.sol', '73094.sol', '7312.sol', '73214.sol', '73215.sol', '73248.sol',
                 '73262.sol', '73460.sol', '73718.sol', '7390.sol', '73954.sol', '73966.sol', '74478.sol', '7505.sol', '75194.sol', '75232.sol', '75234.sol', '75241.sol', '75414.sol',
                 '75487.sol', '7558.sol', '75619.sol', '75709.sol', '76149.sol', '76242.sol', '76469.sol', '76675.sol', '76948.sol', '77167.sol', '77203.sol', '77252.sol', '77325.sol',
                 '77336.sol', '7759.sol', '77619.sol', '78068.sol', '78129.sol', '78396.sol', '78505.sol', '78511.sol', '79166.sol', '79306.sol', '79504.sol', '7952.sol', '79585.sol',
                 '80031.sol', '80143.sol', '80556.sol', '80953.sol', '81323.sol', '81481.sol', '81567.sol', '81669.sol', '81715.sol', '81952.sol', '81966.sol', '82056.sol', '82087.sol',
                 '82191.sol', '82333.sol', '82383.sol', '82482.sol', '82780.sol', '82821.sol', '82843.sol', '83060.sol', '83127.sol', '83389.sol', '83807.sol', '83959.sol', '8399.sol',
                 '84155.sol', '84574.sol', '8461.sol', '84655.sol', '84846.sol', '85277.sol', '85443.sol', '85603.sol', '85639.sol', '85705.sol', '86713.sol', '86763.sol', '86949.sol',
                 '87149.sol', '87256.sol', '87270.sol', '87313.sol', '87344.sol', '87520.sol', '87715.sol', '87862.sol', '87866.sol', '88006.sol', '8812.sol', '88142.sol', '88421.sol',
                 '88530.sol', '88761.sol', '88825.sol', '89412.sol', '89795.sol', '89871.sol', '90091.sol', '90268.sol', '90348.sol', '90402.sol', '9057.sol', '90981.sol', '91721.sol',
                 '92004.sol', '92061.sol', '92072.sol', '92227.sol', '92562.sol', '92563.sol', '92710.sol', '92843.sol', '92950.sol', '93031.sol', '93392.sol', '93520.sol', '93649.sol',
                 '93926.sol', '94349.sol', '94350.sol', '94354.sol', '94667.sol', '94752.sol', '94754.sol', '95200.sol', '95272.sol', '95574.sol', '95766.sol', '95801.sol', '96000.sol',
                 '96153.sol', '96316.sol', '9657.sol', '9671.sol', '9685.sol', '9690.sol', '9719.sol', '97387.sol', '97491.sol', '97548.sol', '97563.sol', '97593.sol', '97791.sol',
                 '97925.sol', '98110.sol', '98260.sol', '98963.sol', '98966.sol', '99216.sol', '99439.sol', '99620.sol', '9968.sol', '9974.sol', '99918.sol']
"""
S, W, C nips_features: Node nips_features + Edge nips_features + Var nips_features;
Node self property + Incoming Var + Outgoing Var + Incoming Edge + Outgoing Edge
"""

dict_AC = {"NULL": 0, "LimitedAC": 1, "NoLimit": 2}

dict_NodeName = {"NULL": 0, "VAR0": 1, "VAR1": 2, "VAR2": 3, "VAR3": 4, "VAR4": 5, "VAR5": 6, "S": 7, "W0": 8,
                 "W1": 9, "W2": 10, "W3": 11, "W4": 12, "C0": 13, "C1": 14, "C2": 15, "C3": 16, "C4": 17,"F":18}

dict_VarOpName = {"NULL": 0, "BOOL": 1, "ASSIGN": 2}

dict_EdgeOpName = {"NULL": 0, "FW": 1, "IF": 2, "GB": 3, "GN": 4, "WHILE": 5, "FOR": 6, "RE": 7, "AH": 8, "RG": 9,
                   "RH": 10, "IT": 11}

dict_AllOpName = {"NULL": 0, "FW": 1, "ASSIGN": 2, "BOOL": 3, "IF": 4, "GB": 5, "GN": 6, "WHILE": 7, "FOR": 8, "RE": 9,
                  "AH": 10, "RG": 11, "RH": 12, "IT": 13}

dict_NodeOpName = {"NULL": 0, "MSG": 1, "INNADD": 2}

dict_ConName = {"NULL": 0, "ARG1": 1, "ARG2": 2, "ARG3": 3, "CON1": 4, "CON2": 5, "CON3": 6, "CNS1": 7, "CNS2": 8,
                "CNS3": 9}

node_convert = {"S": 0,"F":1, "W0": 2, "C0": 3, "W1": 4, "C1": 5, "W2": 6, "C2": 7, "W3": 8, "C3": 9, "W4": 10, "C4": 11,
                "VAR0": 0, "VAR1": 1, "VAR2": "VAR2", "VAR3": "VAR3", "VAR4": "VAR4", "VAR5": "VAR5"}

v2o = vec2onehot()  # create the one-bot dicts


# extract the nips_features of each node from input file #
def extract_node_features(nodeFile):
    nodeNum = 0
    node_list = []
    node_attribute_list = []

    f = open(nodeFile)
    lines = f.readlines()
    f.close()

    for line in lines:
        node = list(map(str, line.split()))
        verExist = False
        for i in range(0, len(node_list)):
            if node[1] == node_list[i]:
                verExist = True
            else:
                continue
        if verExist is False:
            node_list.append(node[1])
            nodeNum += 1
        node_attribute_list.append(node)

    return nodeNum, node_list, node_attribute_list


# elimination procedure for sub_graph Start here #
def elimination_node(node_attribute_list):
    main_point = ['S', 'W0', 'W1', 'W2', 'W3', 'W4', 'C0', 'C1', 'C2', 'C3', 'C4', 'F']
    extra_var_list = []  # extract var with low priority
    for i in range(0, len(node_attribute_list)):
        if node_attribute_list[i][1] not in main_point:
            if i + 1 < len(node_attribute_list):
                if node_attribute_list[i][1] == node_attribute_list[i + 1][1]:
                    loc1 = int(node_attribute_list[i][3])  # relative location
                    op1 = node_attribute_list[i][4]  # operation
                    loc2 = int(node_attribute_list[i + 1][3])
                    op2 = node_attribute_list[i + 1][4]
                    if loc2 - loc1 == 1:
                        op1_index = dict_VarOpName[op1]
                        op2_index = dict_VarOpName[op2]
                        # extract node attribute based on priority
                        if op1_index < op2_index:
                            extra_var_list.append(node_attribute_list.pop(i))
                        else:
                            extra_var_list.append(node_attribute_list.pop(i + 1))
    return node_attribute_list, extra_var_list


def embedding_node(node_attribute_list):
    # embedding each node after elimination #
    node_encode = []
    var_encode = []
    node_embedding = []
    var_embedding = []
    main_point = ['S', 'W0', 'W1', 'W2', 'W3', 'W4', 'C0', 'C1', 'C2', 'C3', 'C4', 'F']

    for j in range(0, len(node_attribute_list)):
        v = node_attribute_list[j][0]
        if v in main_point:
            vf0 = node_attribute_list[j][0]
            vf1 = dict_NodeName[node_attribute_list[j][1]]
            vfm1 = v2o.node2vecEmbedding(node_attribute_list[j][1])
            vf2 = dict_AC[node_attribute_list[j][2]]
            vfm2 = v2o.nodeAC2vecEmbedding(node_attribute_list[j][2])

            result = node_attribute_list[j][3].split(",")
            for call_vec in range(len(result)):
                if call_vec + 1 < len(result):
                    tmp_vf = str(dict_NodeName[result[call_vec]]) + "," + str(dict_NodeName[result[call_vec + 1]])
                    tmp_vfm = np.array(list(v2o.node2vecEmbedding(result[call_vec]))) ^ np.array(
                        list(v2o.node2vecEmbedding(result[call_vec + 1])))
                elif len(result) == 1:
                    tmp_vf = dict_NodeName[result[call_vec]]
                    tmp_vfm = v2o.node2vecEmbedding(result[call_vec])
            vf3 = tmp_vf
            vfm3 = tmp_vfm
            vf4 = int(node_attribute_list[j][4])
            vfm4 = v2o.sn2vecEmbedding(node_attribute_list[j][4])
            vf5 = dict_NodeOpName[node_attribute_list[j][5]]
            vfm5 = v2o.nodeOP2vecEmbedding(node_attribute_list[j][5])
            nodeEmbedding = vfm1.tolist() + vfm2.tolist() + vfm3.tolist() + vfm4.tolist() + vfm5.tolist()
            node_embedding.append([vf0, np.array(nodeEmbedding)])
            temp = [vf1, vf2, vf3, vf4, vf5]
            node_encode.append([vf0, temp])
        else:
            vf0 = node_attribute_list[j][0]
            vf1 = dict_NodeName[node_attribute_list[j][1]]
            vfm1 = v2o.node2vecEmbedding(node_attribute_list[j][1])
            vf2 = dict_NodeName[node_attribute_list[j][2]]
            vfm2 = v2o.node2vecEmbedding(node_attribute_list[j][2])
            vf3 = int(node_attribute_list[j][3])
            vfm3 = v2o.sn2vecEmbedding(node_attribute_list[j][3])
            vf4 = dict_VarOpName[node_attribute_list[j][4]]
            vfm4 = v2o.varOP2vecEmbedding(node_attribute_list[j][4])
            vf5 = int(dict_NodeOpName['NULL'])
            vfm5 = v2o.nodeOP2vecEmbedding('NULL')
            varEmbedding = vfm1.tolist() + vfm2.tolist() + vfm3.tolist() + vfm4.tolist() + vfm5.tolist()
            var_embedding.append([vf0, np.array(varEmbedding)])
            temp = [vf1, vf2, vf3, vf4, vf5]
            var_encode.append([vf0, temp])

    return node_encode, var_encode, node_embedding, var_embedding


def elimination_edge(edgeFile):
    # eliminate edge #
    edge_list = []  # all edge
    extra_edge_list = []  # eliminated edge

    f = open(edgeFile)
    lines = f.readlines()
    f.close()

    for line in lines:
        edge = list(map(str, line.split()))
        edge_list.append(edge)

    # The ablation of multiple edge between two nodes, taking the edge with the edge_operation priority
    for k in range(0, len(edge_list)):
        if k + 1 < len(edge_list):
            start1 = edge_list[k][0]  # start node
            end1 = edge_list[k][1]  # end node
            op1 = edge_list[k][4]
            start2 = edge_list[k + 1][0]
            end2 = edge_list[k + 1][1]
            op2 = edge_list[k + 1][4]
            if start1 == start2 and end1 == end2:
                op1_index = dict_EdgeOpName[op1]
                op2_index = dict_EdgeOpName[op2]
                # extract edge attribute based on priority
                if op1_index < op2_index:
                    extra_edge_list.append(edge_list.pop(k))
                else:
                    extra_edge_list.append(edge_list.pop(k + 1))

    return edge_list, extra_edge_list


def embedding_edge(edge_list):
    # extract & embedding the features of each edge from input file #
    edge_encode = []
    edge_embedding = []

    for k in range(len(edge_list)):
        start = edge_list[k][0]  # start node
        end = edge_list[k][1]  # end node
        a, b, c = edge_list[k][2], edge_list[k][3], edge_list[k][4]  # origin info

        ef1 = dict_NodeName[a]
        ef2 = int(b)
        ef3 = dict_EdgeOpName[c]

        ef_temp = [ef1, ef2, ef3]
        edge_encode.append([start, end, ef_temp])

        efm1 = v2o.node2vecEmbedding(a)
        efm2 = v2o.sn2vecEmbedding(b)
        efm3 = v2o.edgeOP2vecEmbedding(c)

        efm_temp = efm1.tolist() + efm2.tolist() + efm3.tolist()
        edge_embedding.append([start, end, np.array(efm_temp)])

    return edge_encode, edge_embedding


def construct_vec(edge_list, node_embedding, var_embedding, edge_embedding, edge_encode):
    # Vec: Node self property + Incoming Var + Outgoing Var + Incoming Edge + Outgoing Edge
    print("Start constructing node vector...")
    var_in_node = []
    var_in = []
    var_out_node = []
    var_out = []
    edge_in_node = []
    edge_in = []
    edge_out_node = []
    edge_out = []
    node_vec = []
    F_point = ['F']
    S_point = ['S']
    W_point = ['W0', 'W1', 'W2', 'W3', 'W4']
    C_point = ['C0', 'C1', 'C2', 'C3', 'C4']
    main_point = ['S', 'W0', 'W1', 'W2', 'W3', 'W4', 'C0', 'C1', 'C2', 'C3', 'C4', 'F']
    node_embedding_dim_without_edge = 250

    if len(var_embedding) > 0:
        for k in range(len(edge_embedding)):
            if edge_list[k][0] in F_point:
                for i in range(len(var_embedding)):
                    if str(var_embedding[i][0]) == str(edge_embedding[k][1]):
                        var_out.append([edge_embedding[k][0], var_embedding[i][1]])
                        edge_out.append([edge_embedding[k][0], edge_embedding[k][2]])
            elif edge_list[k][1] in F_point:
                for i in range(len(var_embedding)):
                    if str(var_embedding[i][0]) == str(edge_embedding[k][0]):
                        var_in.append([edge_embedding[k][1], var_embedding[i][1]])
                        edge_in.append([edge_embedding[k][1], edge_embedding[k][2]])

            if edge_list[k][0] in C_point:
                for i in range(len(var_embedding)):
                    if str(var_embedding[i][0]) == str(edge_embedding[k][1]):
                        var_out.append([edge_embedding[k][0], var_embedding[i][1]])
                        edge_out.append([edge_embedding[k][0], edge_embedding[k][2]])
            elif edge_list[k][1] in C_point:
                for i in range(len(var_embedding)):
                    if str(var_embedding[i][0]) == str(edge_embedding[k][0]):
                        var_in.append([edge_embedding[k][1], var_embedding[i][1]])
                        edge_in.append([edge_embedding[k][1], edge_embedding[k][2]])

            elif edge_list[k][0] in W_point:
                for i in range(len(var_embedding)):
                    if str(var_embedding[i][0]) == str(edge_embedding[k][1]):
                        var_out.append([edge_embedding[k][0], var_embedding[i][1]])
                        edge_out.append([edge_embedding[k][0], edge_embedding[k][2]])
                        break
            elif edge_list[k][1] in W_point:
                for i in range(len(var_embedding)):
                    if str(var_embedding[i][0]) == str(edge_embedding[k][0]):
                        var_in.append([edge_embedding[k][1], var_embedding[i][1]])
                        edge_in.append([edge_embedding[k][1], edge_embedding[k][2]])

            elif edge_list[k][0] in S_point:
                S_OUT = []
                S_OUT_Flag = 0
                for i in range(len(var_embedding)):
                    if str(var_embedding[i][0]) == str(edge_embedding[k][1]):
                        S_OUT.append(var_embedding[i][1])
                        S_OUT_Flag = 1
                if S_OUT_Flag != 1:
                    S_OUT.append(np.zeros(len(var_embedding[0][1]), dtype=int))
                var_out.append([edge_embedding[k][0], S_OUT[0]])
                edge_out.append([edge_embedding[k][0], edge_embedding[k][2]])
            elif edge_list[k][1] in S_point:
                for i in range(len(var_embedding)):
                    if str(var_embedding[i][0]) == str(edge_embedding[k][0]):
                        var_in.append([edge_embedding[k][1], var_embedding[i][1]])
                        edge_in.append([edge_embedding[k][1], edge_embedding[k][2]])
                        break
            else:
                print("Edge from node %s to node %s:  edgeFeature: %s" % (
                    edge_embedding[k][0], edge_embedding[k][1], edge_embedding[k][2]))
    else:
        for k in range(len(edge_embedding)):
            if edge_list[k][0] in F_point:
                edge_out.append([edge_embedding[k][0], edge_embedding[k][2]])
            elif edge_list[k][1] in F_point:
                edge_in.append([edge_embedding[k][1], edge_embedding[k][2]])

            if edge_list[k][0] in C_point:
                edge_out.append([edge_embedding[k][0], edge_embedding[k][2]])
            elif edge_list[k][1] in C_point:
                edge_in.append([edge_embedding[k][1], edge_embedding[k][2]])

            elif edge_list[k][0] in W_point:
                edge_out.append([edge_embedding[k][0], edge_embedding[k][2]])
            elif edge_list[k][1] in W_point:
                edge_in.append([edge_embedding[k][1], edge_embedding[k][2]])

            elif edge_list[k][0] in S_point:
                edge_out.append([edge_embedding[k][0], edge_embedding[k][2]])
            elif edge_list[k][1] in S_point:
                edge_in.append([edge_embedding[k][1], edge_embedding[k][2]])

    edge_vec_length = 44
    var_vec_length = 61

    for i in range(len(var_in)):
        var_in_node.append(var_in[i][0])
    for i in range(len(var_out)):
        var_out_node.append(var_out[i][0])
    for i in range(len(edge_in)):
        edge_in_node.append(edge_in[i][0])
    for i in range(len(edge_out)):
        edge_out_node.append(edge_out[i][0])

    for i in range(len(main_point)):
        if main_point[i] not in var_in_node:
            var_in.append([main_point[i], np.zeros(var_vec_length, dtype=int)])
        if main_point[i] not in var_out_node:
            var_out.append([main_point[i], np.zeros(var_vec_length, dtype=int)])
        if main_point[i] not in edge_out_node:
            edge_out.append([main_point[i], np.zeros(edge_vec_length, dtype=int)])
        if main_point[i] not in edge_in_node:
            edge_in.append([main_point[i], np.zeros(edge_vec_length, dtype=int)])

    varIn_dict = dict(var_in)
    varOut_dict = dict(var_out)
    edgeIn_dict = dict(edge_in)
    edgeOut_dict = dict(edge_out)

    for i in range(len(node_embedding)):
        vec = np.zeros(node_embedding_dim_without_edge, dtype=int)
        if node_embedding[i][0] in F_point:
            node_feature = node_embedding[i][1].tolist() + np.array(varIn_dict[node_embedding[i][0]]).tolist() + \
                           np.array(varOut_dict[node_embedding[i][0]]).tolist()
            vec[0:len(np.array(node_feature))] = np.array(node_feature)
            node_vec.append([node_embedding[i][0], vec])
        elif node_embedding[i][0] in S_point:
            node_feature = node_embedding[i][1].tolist() + np.array(varIn_dict[node_embedding[i][0]]).tolist() + \
                           np.array(varOut_dict[node_embedding[i][0]]).tolist()
            vec[0:len(np.array(node_feature))] = np.array(node_feature)
            node_vec.append([node_embedding[i][0], vec])
        elif node_embedding[i][0] in W_point:
            node_feature = node_embedding[i][1].tolist() + np.array(varIn_dict[node_embedding[i][0]]).tolist() + \
                           np.array(varOut_dict[node_embedding[i][0]]).tolist()
            vec[0:len(np.array(node_feature))] = np.array(node_feature)
            node_vec.append([node_embedding[i][0], vec])
        elif node_embedding[i][0] in C_point:
            node_feature = node_embedding[i][1].tolist() + np.array(varIn_dict[node_embedding[i][0]]).tolist() + \
                           np.array(varOut_dict[node_embedding[i][0]]).tolist()
            vec[0:len(np.array(node_feature))] = np.array(node_feature)
            node_vec.append([node_embedding[i][0], vec])

    for i in range(len(node_vec)):
        node_vec[i][1] = node_vec[i][1].tolist()

    print("Node Vec:")
    for i in range(len(node_vec)):
        node_vec[i][0] = node_convert[node_vec[i][0]]
        print(node_vec[i][0], node_vec[i][1])

    for i in range(len(edge_embedding)):
        edge_embedding[i][2] = edge_embedding[i][2].tolist()

    # "S" -> 0, W0 -> 1, C0 -> 2
    if len(edge_encode) == 2:
        end = edge_encode[len(edge_encode) - 2][1]
        start = edge_encode[len(edge_encode) - 1][0]
        flag = edge_encode[len(edge_encode) - 1][1]
        if end == start and ('VAR' in flag or 'MSG' in flag):
            edge_encode[len(edge_encode) - 1][1] = edge_encode[len(edge_encode) - 2][0]

    if len(edge_encode) > 2:
        end1 = edge_encode[len(edge_encode) - 1][1]
        start2 = edge_encode[len(edge_encode) - 2][0]
        if end1 == start2 and ('VAR' in end1 or 'MSG' in end1):
            edge_encode[len(edge_encode) - 1][1] = edge_encode[len(edge_encode) - 3][0]

    for i in range(len(edge_encode)):
        if i + 1 < len(edge_encode):
            start1 = edge_encode[i][0]
            end1 = edge_encode[i][1]
            start2 = edge_encode[i + 1][0]

            if end1 == start2 and ('VAR' in end1 or 'MSG' in end1):
                edge_encode[i][1] = edge_encode[i + 1][1]
                edge_encode[i + 1][0] = edge_encode[i][0]
            elif 'W' in start1 and 'VAR' in end1:
                edge_encode[i][1] = 'S'

    print("Edge Vec:")
    for i in range(len(edge_encode)):
        edge_encode[i][0] = node_convert[edge_encode[i][0]]
        edge_encode[i][1] = node_convert[edge_encode[i][1]]
        print(edge_encode[i][0], edge_encode[i][1], edge_encode[i][2])

    graph_edge = []

    for i in range(len(edge_encode)):
        graph_edge.append([edge_encode[i][0], edge_encode[i][2][2], edge_encode[i][1]])
    node_dict = {}
    for i in range(len(node_vec)):
        node_index = node_vec[i][0]
        node_dict[node_index] = i
    new_lst = [[node_dict.get(sublst[0], sublst[0]), sublst[1], node_dict.get(sublst[2], sublst[2])] for sublst in graph_edge]
    return node_vec, new_lst


if __name__ == "__main__":
    node_path = "../../data/reentrancy/graph/node"
    edge_path = "../../data/reentrancy/graph/edge"
    input_file = os.listdir(node_path)
    all_dict = []
    fullnodes_ouptput_tmp = open("source_code_graph_encodding.json", "a")
    for file in input_file:
        print(file)
        flag = None
        if file in vulnerability:
            flag = 1
        else:
            flag = 0
        node = os.path.join(node_path, file)
        edge = os.path.join(edge_path,file)
        nodeNum, node_list, node_attribute_list = extract_node_features(node)
        node_attribute_list, extra_var_list = elimination_node(node_attribute_list)
        node_encode, var_encode, node_embedding, var_embedding = embedding_node(node_attribute_list)
        edge_list, extra_edge_list = elimination_edge(edge)
        edge_encode, edge_embedding = embedding_edge(edge_list)
        node_vec,graph_edge  = construct_vec(edge_list, node_embedding, var_embedding, edge_embedding, edge_encode)
        # graph_edge = edge_eliminate(graph_edge)
        # graph_edge,node_vec = add_node(node_vec,graph_edge)
        # node_embedding = sorted(node_embedding, key=lambda x: (x[0]))
        # var_embedding = sorted(var_embedding, key=lambda x: (x[0]))
        # fullnodes_feature_list = []
        # for i in range(len(node_embedding)):
        #     fullnodes_feature_list.append(node_embedding[i][1])
        # for i in range(len(var_embedding)):
        #     fullnodes_feature_list.append(var_embedding[i][1])
        # edge_dict = {
        #     "graph_data": graph_edge
        # }
        corenodes_feature_list = []
        for i in range(len(node_vec)):
            corenodes_feature_list.append(node_vec[i][1])
        # node_feature_dict = {
        #     "node_features": corenodes_feature_list,
        # }

        fullnode_graph_dict = ({
            "targets":str(flag),
            "graph_data": graph_edge,  # graph_edge,
            "contract_name": file,
            "node_features": corenodes_feature_list,  # corenodes_feature_list
        })
        result = json.dumps(fullnode_graph_dict)
        fullnodes_ouptput_tmp.write(result + "," + "\n")









    # v_path = "../../data/reentrancy/graph_data/node/"
    # e_path = "../../data/reentrancy/graph_data/edge/"
    #
    # corenodes_output_tmp = open('./results/Reentrancy_AutoExtract_corenodes.json', 'w')
    # fullnodes_ouptput_tmp = open('./results/Reentrancy_AutoExtract_fullnodes.json', 'w')
    # corenodes_ouptput_gcn = open('./results/Reentrancy_AutoExtract_corenodes.txt', 'a')
    # fullnodes_ouptput_gcn = open('./results/Reentrancy_AutoExtract_fullnodes.txt', 'a')
    # contract_name = open("./reentrancy_contract_name.txt")  # contracts list
    # contract_label = open("./reentrancy_contract_label.txt")  # contracts label
    # names = contract_name.readline().strip(" ")
    # labels = contract_label.readline()
    # while names:
    #     node = os.path.join(v_path, names.strip('\n'))
    #     edge = os.path.join(e_path, names.strip('\n'))
    #     print(node)
    #     nodeNum, node_list, node_attribute_list = extract_node_features(node)
    #     node_attribute_list, extra_var_list = elimination_node(node_attribute_list)
    #     node_encode, var_encode, node_embedding, var_embedding = embedding_node(node_attribute_list)
    #
    #     edge_list, extra_edge_list = elimination_edge(edge)
    #     edge_encode, edge_embedding = embedding_edge(edge_list)
    #     node_vec, graph_edge = construct_vec(edge_list, node_embedding, var_embedding, edge_embedding, edge_encode)
    #
    #     node_embedding = sorted(node_embedding, key=lambda x: (x[0]))
    #     var_embedding = sorted(var_embedding, key=lambda x: (x[0]))
    #     fullnodes_ouptput_gcn.write(names)
    #     corenodes_ouptput_gcn.write(names)
    #
    #     for k in range(len(node_embedding)):
    #         node_embedding[k][1].astype(np.float64)
    #         node_embedding[k][1] = node_embedding[k][1].tolist()
    #         fullnodes_ouptput_gcn.write(str(node_embedding[k][0]) + ":" + str(node_embedding[k][1]) + '\n')
    #     for k in range(len(var_embedding)):
    #         var_embedding[k][1].astype(np.float64)
    #         var_embedding[k][1] = var_embedding[k][1].tolist()
    #         fullnodes_ouptput_gcn.write(str(var_embedding[k][0]) + ":" + str(var_embedding[k][1]) + '\n')
    #     for k in range(len(node_vec)):
    #         corenodes_ouptput_gcn.write(str(node_vec[k][0]) + ":" + str(node_vec[k][1]) + '\n')
    #
    #     corenodes_feature_list = []
    #     for i in range(len(node_vec)):
    #         corenodes_feature_list.append(node_vec[i][1])
    #
    #     fullnodes_feature_list = []
    #     for i in range(len(node_embedding)):
    #         fullnodes_feature_list.append(node_embedding[i][1])
    #     for i in range(len(var_embedding)):
    #         fullnodes_feature_list.append(var_embedding[i][1])
    #
    #     edge_dict = {
    #         "graph_data": graph_edge
    #     }
    #
    #     node_feature_dict = {
    #         "node_features": corenodes_feature_list,
    #     }
    #
    #     graph_dict = ({
    #         "targets": labels.strip('\n'),
    #         "graph_data": graph_edge,  # graph_edge,
    #         "contract_name": names.strip('\n'),
    #         "node_features": corenodes_feature_list,  # corenodes_feature_list
    #     })
    #
    #     fullnode_graph_dict = ({
    #         "targets": labels.strip('\n'),
    #         "graph_data": graph_edge,  # graph_edge,
    #         "contract_name": names.strip('\n'),
    #         "node_features": fullnodes_feature_list,  # corenodes_feature_list
    #     })
    #
    #     result = json.dumps(graph_dict)
    #     fullnodes_result = json.dumps(fullnode_graph_dict)
    #
    #     corenodes_output_tmp.write(result + "," + "\n")
    #     fullnodes_ouptput_tmp.write(fullnodes_result + "," + "\n")
    #     names = contract_name.readline()
    #     labels = contract_label.readline()
    #
    # fullnodes_ouptput_gcn.close()
    # corenodes_ouptput_gcn.close()
    # corenodes_output_tmp.close()
    # fullnodes_ouptput_tmp.close()