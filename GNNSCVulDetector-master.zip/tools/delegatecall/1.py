import json
with open('delegatecall_train.json','r')as f:
    contents = json.loads(f.read())
f.close()
new_data = []
for data in contents:
    name = data['contract_name']
    graph = data['graph']
    node_features = data['node_features']
    target = data['targets']
    new_node_features = []
    for node_feature in node_features:
        node_feature += [0]*(250-len(node_feature))
        new_node_features.append(node_feature)
    s = {
        'contract_name': data['contract_name'],
        'targets': target,
        'graph_data': graph,
        'node_features': new_node_features,
    }
    new_data.append(s)
f = open('delegatecall_source_feature.json', 'w')  # 输出
f.write('[')
for i in range(len(new_data)):
    print(i)
    if i == len(new_data) - 1:
        data_final = json.dumps(new_data[i])
        f.write(data_final)
        f.write(']')
    else:
        data_final = json.dumps(new_data[i])
        f.write(data_final)
        f.write(',')
        f.write('\n')

