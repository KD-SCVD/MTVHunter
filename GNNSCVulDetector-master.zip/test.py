import json

import torch
import torch.nn as nn
import torch.optim as optim



class MLP(nn.Module):
    def __init__(self, input_size, hidden_size, output_size,condition=False):
        super(MLP, self).__init__()
        self.fc1 = nn.Linear(input_size*4, hidden_size)
        self.fc2 = nn.Linear(hidden_size, output_size)
        self.condition = condition
        self.activation = nn.Sigmoid()

    def forward(self, x,condition):
        batch_size = x.size(0)   # 获取批次大小
        x = x.view(batch_size, -1)  # 将张量展平成形状为 (batch_size, input_size*4) 的张量
        x = self.fc1(x)
        x = self.activation(x)
        if condition == True:
            mid_output = x
            return mid_output
        x = self.fc2(x)
        return x.squeeze()
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
def evaluate(outputs, targets):
    # 计算各种指标
    accuracy = accuracy_score(targets, outputs)
    precision = precision_score(targets, outputs)
    recall = recall_score(targets, outputs)
    f1 = f1_score(targets, outputs)
    tn, fp, fn, tp = confusion_matrix(targets, outputs).ravel()

    print(f'Accuracy: {accuracy:.4f}, Precision: {precision:.4f}, Recall: {recall:.4f}, F1 score: {f1:.4f}')
    print(f'TP: {tp}, FP: {fp}, TN: {tn}, FN: {fn}')

    return accuracy, precision, recall, f1, tn, fp, fn, tp
if __name__ == "__main__":
    source_features_inputfile ='timestamp_feature_train.json'
    with open(source_features_inputfile,'r') as f:
        content = json.load(f)
        f.close()
    all_data = []
    all_labels = []
    for data in content:
        source_features = data['source_features']
        target = int(data['target'])
        all_data.append(source_features)
        all_labels.append(target)
    # 假设您已经定义了一个名为 MLP 的多层感知器模型
    model = MLP(input_size=512, hidden_size=256, output_size=1,condition=False)

    # 定义损失函数和优化器
    criterion = nn.MSELoss()
    optimizer = optim.SGD(model.parameters(), lr=0.01)
    # 训练过程
    epochs = 10
    batch_size = 128
    model.train()
    for epoch in range(epochs):
        for i in range(len(all_data)//batch_size):
            input_data = torch.Tensor(all_data[i*batch_size:(i+1)*batch_size]).reshape(-1, 4, 512)
            targets = torch.Tensor(all_labels[i*batch_size:(i+1)*batch_size])
            # 前向传播
            outputs = model(input_data,False)

            # 计算损失
            loss = criterion(outputs, targets)

            # 反向传播和优化
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        # 打印当前训练损失
        print(f"Epoch {epoch+1}/{epochs}, Loss: {loss.item()}")
    model.eval()
    all_data = torch.Tensor(all_data).reshape(-1, 4, 512)
    targets = torch.Tensor(all_labels)
    mid_output = model(all_data,True).tolist()


    # f = open('source_features_final.json', 'w')  # 输出
    # f.write('[')
    # for i in range(len(mid_output)):
    #     print(i)
    #     if i == len(mid_output) - 1:
    #         data_final = json.dumps(mid_output[i])
    #         f.write(data_final)
    #         f.write(']')
    #     else:
    #         data_final = json.dumps(mid_output[i])
    #         f.write(data_final)
    #         f.write(',')
    #         f.write('\n')


    predictions = []
    for _ in outputs:
        if _<= 0.57:
            predictions.append(0)
        else:
            predictions.append(1)


    acc,tp,tn,fp,fn = accuracy(predictions,targets)
    # 训练完成后，您可以使用模型进行推理等操作
